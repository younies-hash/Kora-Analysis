// import 'package:firebase_core/firebase_core.dart';
// import 'package:flutter/widgets.dart';
// import 'package:kora_analysis/BL/Players/player.dart';
// import 'package:kora_analysis/DB/api.dart';
// import 'package:kora_analysis/firebase_options.dart';

// class DBCache with ChangeNotifier {
//   late final FirebaseApp initialization;
//   DBCache() {
//     initFirebase();
//   }
//   Future<void> initFirebase() async {
//     initialization = await Firebase.initializeApp(
//       options: DefaultFirebaseOptions.currentPlatform,
//     );
//   }

//   static List<Player> getMostCommen() {
//     List<Player> result = [];
//     API.db
//         .collection(DBCollection.players.id)
//         .orderBy("points")
//         .get()
//         .then((orderdList) {
//       result.addAll(
//         orderdList.docs.map((doc) => Player.fromMap(doc.data())).toList(),
//       );
//     });
//     return result;
//   }
// }
