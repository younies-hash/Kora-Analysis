// import 'package:flutter/material.dart';
// import 'package:kora_analysis/Admin%20tools/Admin%20Providers/admin_cache.dart';
// import 'package:kora_analysis/DB/api.dart';
// import 'package:kora_analysis/Providers/match_cache.dart';
// import 'package:kora_analysis/Providers/player_cache.dart';
// import 'package:kora_analysis/Providers/team_cache.dart';
// import 'package:kora_analysis/Providers/user_cache.dart';
// import 'package:provider/provider.dart';

// class Counters {
//   final String name, doc;
//   const Counters(this.name, this.doc);
// }

// Counters playersCounter = const Counters("playersCount", "players");
// Counters teamsCounter = const Counters("teamsCount", "teams");
// Counters tournamentsCounter = const Counters("tournamentsCount", "tournaments");
// Counters matchesCounter = const Counters("matchesCount", "matches");
// Counters usersCounter = const Counters("usersCount", "users");
// Counters adminsCounter = const Counters("adminsCount", "admins");

// class CounterProvider with ChangeNotifier {
//   late int playersCount,
//       teamsCount,
//       tournamentsCount,
//       matchesCount,
//       usersCount,
//       adminsCount;
//   CounterProvider() {
//     getCounter(playersCount, playersCounter);
//     getCounter(teamsCount, teamsCounter);
//     getCounter(tournamentsCount, tournamentsCounter);
//     getCounter(matchesCount, matchesCounter);
//     getCounter(usersCount, usersCounter);
//     getCounter(adminsCount, adminsCounter);
//     notifyListeners();
//   }
//   void getCounter(int counter, Counters counterInfo) {
//     API.db.collection(DBCollection.counters.id).doc(counterInfo.doc).get().then(
//         (data) {
//       counter = data.data()?[counterInfo.name] as int;
//     }, onError: (_) {
//       API.db.collection(DBCollection.counters.id).doc(counterInfo.doc).set({
//         counterInfo.name: 0,
//       });
//       API.db
//           .collection(DBCollection.counters.id)
//           .doc(counterInfo.doc)
//           .get()
//           .then((data) {
//         counter = data.data()?[counterInfo.name] as int;
//       });
//     });
//   }

//   // refreshCount(BuildContext context) {
//   //   Provider.of<CounterProvider>(context).playersCount =
//   //       Provider.of<PlayerCache>(context).getPlayers().length;
//   //   //
//   //   Provider.of<CounterProvider>(context).teamsCount =
//   //       Provider.of<TeamsCache>(context).getTeams().length;
//   //   //
//   //   Provider.of<CounterProvider>(context).tournamentsCount =
//   //       Provider.of<MatchCache>(context).getTournaments().length;
//   //   //
//   //   Provider.of<CounterProvider>(context).matchesCount =
//   //       Provider.of<MatchCache>(context).getMatches().length;
//   //   //
//   //   Provider.of<CounterProvider>(context).usersCount =
//   //       Provider.of<KoraUserCache>(context).getKoraUsers().length;
//   //   //
//   //   Provider.of<CounterProvider>(context).adminsCount =
//   //       Provider.of<AdminCache>(context).getAdmins().length;
//   //   notifyListeners();
//   // }
// }
