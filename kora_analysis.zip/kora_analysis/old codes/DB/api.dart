import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

abstract class API<T> {
  static FirebaseFirestore db = FirebaseFirestore.instance;
  T fetchObj(BuildContext context);
  //dynamic fetchVal(String objId, String valId, context);
  void uploadObj(BuildContext contetxt);
  //void uploadVal(String objId, String valId, context);
}
//TODO: implement api in: teams,matches, tours, user and admins

class DBCollection {
  final String id;
  const DBCollection(this.id);

  static const DBCollection players = DBCollection("players");
  static const DBCollection continents = DBCollection("continents");
  static const DBCollection teams = DBCollection("teams");
  static const DBCollection tournaments = DBCollection("tournaments");
  static const DBCollection matches = DBCollection("matches");
  static const DBCollection users = DBCollection("users");
  static const DBCollection admins = DBCollection("admins");
  static const DBCollection stadium = DBCollection("stadium");
  static const DBCollection country = DBCollection("country");

  static const DBCollection counters = DBCollection("counters");
}

abstract class Mapper {
  Map<String, dynamic> toMap();
}
