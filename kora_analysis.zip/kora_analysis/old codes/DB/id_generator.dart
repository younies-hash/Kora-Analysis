// import 'package:kora_analysis/Providers/counter.dart';

// class IdGenerator{
//     final CounterProvider provider;
//     IdGenerator(this.provider);
//     String generateAdminId(){
//         const String prefix = "ADMIN";
//         String id = provider.adminsCount.toString();
//         for(int i = 5-id.length; i > 0 ;i--){
//             id = '0$id';
//         }
//         return (prefix + id);
//     }
//     String generateKoraUserId(){
//         const String prefix = "USER";
//         String id = provider.usersCount.toString();
//         for(int i = 5-id.length; i > 0 ;i--){
//             id = '0$id';
//         }
//         return (prefix + id);
//     } 
//     String generatePlayerId(){
//         const String prefix = "PLAYER";
//         String id = provider.playersCount.toString();
//         for(int i = 5-id.length; i > 0 ;i--){
//             id = '0$id';
//         }
//         return (prefix + id);
//     } 
//     String generatetournamentId(){
//         const String prefix = "TOUR";
//         String id = provider.tournamentsCount.toString();
//         for(int i = 5-id.length; i > 0 ;i--){
//             id = '0$id';
//         }
//         return (prefix + id);
//     } 
//     String generateTeamId(){
//         const String prefix = "TEAM";
//         String id = provider.teamsCount.toString();
//         for(int i = 5-id.length; i > 0 ;i--){
//             id = '0$id';
//         }
//         return (prefix + id);
//     }  
//     String generateMatchId(){
//         const String prefix = "MATCH";
//         String id = provider.matchesCount.toString();
//         for(int i = 5-id.length; i > 0 ;i--){
//             id = '0$id';
//         }
//         return (prefix + id);
//     }  
// }