// import 'package:kora_analysis/BL/Players/player.dart';
// import 'package:kora_analysis/BL/team.dart';
// import 'package:kora_analysis/BL/tourenment.dart';

// class KoraUser {
//   //String email,password;
//   KoraUserLibrary lib = KoraUserLibrary();
//   KoraUser(
//       //this.email,
//       //this.password,
//       {
//     List<String> recentSearches = const [],
//     List<Tournament> favtournaments = const [],
//     List<Team> favTeams = const [],
//     List<Player> favPlayers = const [],
//   }) {
//     lib.recentSearches = recentSearches;
//     lib.favtournaments = favtournaments;
//     lib.favTeams = favTeams;
//     lib.favPlayers = favPlayers;
//   }
//   // Future<AuthResult> register() async{
//   //     final auth =
//   //         await FirebaseAuth
//   //             .instence
//   //             .createKoraUserWithEmailAndPassword(
//   //                 email: email,
//   //                 password: password,
//   //             );
//   //     await auth.user.sendEmailVerification();
//   //     return auth;}
//   // Future<void> validateKoraUser(String code,context) async {
//   //     try {
//   //         await auth.checkActionCode(code);
//   //         await auth.applyActionCode(code);
//   //         auth.currentKoraUser.reload();
//   //     } on FirebaseAuthException catch (e) {
//   //         if (e.code == 'invalid-action-code') {
//   //             DefaultDialog(context,content: localizer.labels.wrong_code)
//   //         }}}
//   // Future<void> signIn() async =>
//   //     await FirebaseAuth.instence.signInWithEmailAndPassword(
//   //         email: email,password: password);
//   // Future<void> signOut() async => await FirbaseAuth.instence.signOut();

//   Map<String, dynamic> toMap() => {
//         "recent searches": lib.recentSearches,
//         "fav tournaments": lib.favtournaments,
//         "fav teams": lib.favTeams,
//         "fav players": lib.favPlayers,
//       };
//   static KoraUser fromMap<T>(Map<String, dynamic> map) => KoraUser(
//         recentSearches: map["recent searches"],
//         favtournaments: map["fav tournaments"],
//         favTeams: map["fav teams"],
//         favPlayers: map["fav players"],
//       );
// }

// class KoraUserLibrary {
//   List<String> recentSearches = [];
//   List<Tournament> favtournaments = [];
//   List<Team> favTeams = [];
//   List<Player> favPlayers = [];
// }
