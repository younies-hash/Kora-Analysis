// class TourMapper implements Mapper<Tournament{
//   Tournament fromMap(Map<String, dynamic> map) {
//     return Tournament(
//       id: map['id'],
//       name: map['name'],
//       date: DateTime.parse(map['date']),
//       location: map['location'],
//       organizer: map['organizer'],
//       description: map['description'],
//     );
  
// }