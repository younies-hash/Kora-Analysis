// //UI/routes/Auth routes/validation_page.dart
// import 'package:flutter/material.dart';
// import 'package:kora_analysis/Localization/localizer.dart';
// import 'package:provider/provider.dart';

// class CodeValidPage extends StatefulWidget{
//     const CodeValidPage();

//     _CodeValidPageState createState() => _CodeValidPageState();
// }
// //
// class _CodeValidPageState extends State<CodeValidPage>{
//     final codeController = TextEditingController();
//     //
//     @override
//     Widget build(BuildContext context){
//       final localizer = Provider.of<Localizer>(context);
//         return Center(
//             child: Column(
//                 mainAxisAlignment: MainAxisAlignment.spaceAround,
//                 children: [
//                     TextFormField(
//                         decoration: InputDecoration(
//                             icon: const Icon(Icons.mail),
//                             hintText: localizer.labels.enter_valid_code,
//                         ),
//                         controller: codeController,
//                     ),
//                     RaisedButton(
//                         onPressed: () {
//                             validateUser(codeController.text,context);
//                         },
//                         child: Text(localizer.labels.check_valid_code),
//                     )
//                 ]
//             )
//         )
//     }
// }