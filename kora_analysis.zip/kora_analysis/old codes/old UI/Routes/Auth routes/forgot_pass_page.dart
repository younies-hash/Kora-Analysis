//UI/routes/Auth routes/forgot_pass_page.dart
import 'package:flutter/material.dart';
import 'package:kora_analysis/Localization/localizer.dart';
import 'package:provider/provider.dart';

class ForgotPassPage extends StatefulWidget{
    const ForgotPassPage({super.key});

    @override
      _ForgotPassPageState createState() => _ForgotPassPageState();
}
//
class _ForgotPassPageState extends State<ForgotPassPage>{
    final emailController = TextEditingController();
    //
    @override
    Widget build(BuildContext context){
      final localizer = Provider.of<Localizer>(context);
        return Center(
            child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                    TextFormField(
                        decoration: InputDecoration(
                            icon: const Icon(Icons.mail),
                            hintText: localizer.labels.email,
                        ),
                        controller: emailController,
                    ),
                    ElevatedButton(
                        onPressed: () {
                            //
                        },
                        child: Text(localizer.labels.reset_pass),
                    )
                ]
            )
        );
    }
}