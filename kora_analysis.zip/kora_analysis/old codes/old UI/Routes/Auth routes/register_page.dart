// //UI/routes/Auth routes/register_page.dart
// import 'package:flutter/material.dart';
// import 'package:kora_analysis/Localization/localizer.dart';
// import 'package:provider/provider.dart';

// class RegisterPage extends StatefulWidget{
//     const RegisterPage();

//     _RegisterPageState createState() => _RegisterPageState();
// }
// //
// class _RegisterPageState extends State<RegisterPage>{
//     final emailController = TextEditingController();
//     final passController = TextEditingController();
//     final passConfirmController = TextEditingController();
//     //
//     @override
//     Widget build(BuildContext context){
//       final localizer = Provider.of<Localizer>(context);
//         return Center(
//             child: Column(
//                 mainAxisAlignment: MainAxisAlignment.spaceAround,
//                 children: [
//                     TextFormField(
//                         decoration: InputDecoration(
//                             icon: const Icon(Icons.mail),
//                             hintText: localizer.labels.email,
//                         ),
//                         controller: emailController,
//                     ),
//                     TextFormField(
//                         decoration: InputDecoration(
//                             icon: const Icon(Icons.vpn_key),
//                             hintText: localizer.labels.password,
//                         ),
//                         controller: passController,
//                         //TODO: make this text hidden
//                     ),
//                     TextFormField(
//                         decoration: InputDecoration(
//                             icon: const Icon(Icons.vpn_key),
//                             hintText: localizer.labels.pass_confirm,
//                         ),
//                         controller: passConfirmController,
//                         //TODO: make this text hidden
//                     ),
//                     RaisedButton(
//                         onPressed: () {
//                             passController.text != passConfirmController.text
//                             ? DefaultDialog(context,
//                                 content: localizer.labels.pass_not_same,
//                                 ).show();
//                             : try {
//                                 final provider = KoraUser(
//                                     email: emailController.text,
//                                     password: passController.text,
//                                 );
//                                 final user = await provider.register();
//                                 Provider.of<KoraUserCache>(context).user = provider;
//                                 Navigator.of(context)?
//                                     .pushNamed(RouteGenerator.codeValidPage);
//                             } on FirebaseAuthException catch (e) {
//                                 if (e.code == 'weak-password') {
//                                 DefaultDialog(context,content: "${localizer.labels.error}: ${localizer.labels.weak_pass}").show();
//                                 }
//                                 if (e.code == 'email-already-in-use') {
//                                 DefaultDialog(context,content: "${localizer.labels.error}: ${localizer.labels.email_in_use}",).show();
//                                 }
//                             } catch (e) {
//                                 DefaultDialog(context,content: "${localizer.labels.unkown_error}").show();
//                             }
//                         },
//                         child: Text(localizer.labels.register),
//                     )
//                 ]
//             )
//         )
//     }
// }