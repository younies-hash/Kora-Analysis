// //UI/routes/Auth routes/login_page.dart
// import 'package:flutter/material.dart';
// import 'package:kora_analysis/Localization/localizer.dart';
// import 'package:kora_analysis/UI/Widgets/default_dialog.dart';
// import 'package:provider/provider.dart';

// class LoginPage extends StatefulWidget{
//     const LoginPage();

//     _LoginPageState createState() => _LoginPageState();
// }
// //
// class _LoginPageState extends State<LoginPage>{
//     final emailController = TextEditingController();
//     final passController = TextEditingController();
//     //
//     @override
//     Widget build(BuildContext context){
//       final localizer = Provider.of<Localizer>(context);
//         return Center(
//             child: Column(
//                 mainAxisAlignment: MainAxisAlignment.spaceAround,
//                 children: [
//                     TextFormField(
//                         decoration:  InputDecoration(
//                             icon: Icon(Icons.mail),
//                             hintText: localizer.labels.email,
//                         ),
//                         controller: emailController,
//                     ),
//                     TextFormField(
//                         decoration:  InputDecoration(
//                             icon: Icon(Icons.vpn_key),
//                             hintText: localizer.labels.password,
//                         ),
//                         controller: passController,
//                         //TODO: make this text hidden
//                     ),
//                     ElevatedButton(
//                         onPressed: () {
//                             try {
//                                 final provider = KoraUser(
//                                     email: emailController.text,
//                                     password: passController.text,
//                                 );
//                                 final user = await provider.signIn();
//                             } on FirebaseAuthException catch (e) {
//                                 if (e.code == 'weak-password') {
//                                 DefaultDialog(content: "${localizer.labels.error}: ${localizer.labels.weak_pass}")
//                                     .show();
//                                 }
//                                 if (e.code == 'email-already-in-use') {
//                                 DefaultDialog(content: "${localizer.labels.error}: ${localizer.labels.email_in_use}")
//                                     .show();
//                                 }
//                             } catch (e) {
//                                 DefaultDialog(content: "${localizer.labels.unkown_error}")
//                                     .show();
//                             }
//                         },
//                         child: Text(localizer.labels.login),
//                     )
//                 ]
//             )
//         )
//     }
// }