// import 'package:flutter/material.dart';
// import 'package:kora_analysis/BL/football_match.dart';
// import 'package:kora_analysis/Providers/match_cache.dart';
// import 'package:kora_analysis/UI/Widgets/default_app_bar.dart';
// import 'package:kora_analysis/UI/Widgets/empty_page_widget.dart';
// import 'package:provider/provider.dart';

// class MatchInfoPage extends StatelessWidget {
//   const MatchInfoPage({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final FootballMatch? match = Provider.of<MatchCache>(context).itemCache;
//     return Scaffold(
//         appBar: DefaultAppBar(context),
//         body: match == null
//         ? const EmptyPageNote(): LayoutBuilder(
//           builder: (context, dimensions){
//             return SingleChildScrollView(
//               child: Column(
//                 children: [
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceAround,
//                     children: [
//                       Image.asset("assets/tournaments/${match.tour.logo}"),
//                       Text("${match.team1} / ${match.team2}"),
//                     ],
//                   ),
//                 ],
//               ),
//             );
//           }
//         ),
//     );
//   }
// }