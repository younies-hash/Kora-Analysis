// import 'package:flutter/material.dart';
// import 'package:kora_analysis/BL/football_match.dart';
// import 'package:kora_analysis/Providers/match_cache.dart';
// import 'package:kora_analysis/UI/Routing%20Logic/route_generator.dart';
// import 'package:kora_analysis/UI/Widgets/cards/match_card.dart';
// import 'package:kora_analysis/UI/Widgets/default_app_bar.dart';
// import 'package:kora_analysis/UI/Widgets/empty_page_widget.dart';
// import 'package:kora_analysis/UI/Widgets/list_of_items.dart.dart';
// import 'package:provider/provider.dart';

// class MatchListPage extends StatelessWidget {
//   const MatchListPage({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final cache = Provider.of<MatchCache>(context);
//     return Scaffold(
//       appBar: DefaultAppBar(context),
//       body: SingleChildScrollView(
//         child: cache.listCache.isNotEmpty
//             ? ListOfItems<FootballMatch>(
//                 cache.listCache,
//                 builder: (item, action) => MatchCard(
//                   item,
//                   action: action,
//                 ),
//                 route: RouteGenerator.tourList,
//                 cache: cache,
//               )
//             : const EmptyPageNote(),
//       ),
//     );
//   }
// }
