//UI/routes/career.dart
import 'package:flutter/material.dart';

class CareerPage extends StatelessWidget {
  const CareerPage({super.key});
  @override
  Widget build(BuildContext context) {
    //String title = Provider.of<Localizer>(context).labels.overall_progress;
    return const Center();
  }
}