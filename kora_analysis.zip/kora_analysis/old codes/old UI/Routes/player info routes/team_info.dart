// //UI/routes/team_info_page.dart
// import 'package:flutter/material.dart';
// import 'package:kora_analysis/BL/Players/player.dart';
// import 'package:kora_analysis/BL/team.dart';
// import 'package:kora_analysis/Providers/team_cache.dart';
// import 'package:kora_analysis/UI/Widgets/cards/player_card.dart';
// import 'package:kora_analysis/UI/Widgets/default_app_bar.dart';
// import 'package:kora_analysis/UI/Widgets/empty_page_widget.dart';
// import 'package:provider/provider.dart';

// class TeamInfoPage extends StatelessWidget {
//   const TeamInfoPage({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final Team? team = Provider.of<TeamsCache>(context).team;
//     return Scaffold(
//         appBar: DefaultAppBar(context),
//         body: team == null
//         ? const EmptyPageNote()
//         : LayoutBuilder(
//           builder: (context, dimensions){
//             return SingleChildScrollView(
//               child: Column(
//                 children: [
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceAround,
//                     children: [
//                       Image.asset("assets/teams/${team.logo}"),
//                       Text(team.name),
//                     ],
//                   ),
//                   for(Player p in team.listOfPlayers) PlayerCard(p),
//                 ],
//               ),
//             );
//           }
//         ),
//     );
//   }
// }