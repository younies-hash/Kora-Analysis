// import 'package:flutter/material.dart';
// import 'package:kora_analysis/BL/Players/stats/stat.dart';

// class StatBox extends StatelessWidget {
//   final Stat? stat;
//   final String? altName;
//   const StatBox(this.stat, {this.altName, super.key});
//   @override
//   Widget build(BuildContext context) {
//     return Center(
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           Text(
//             altName ?? (stat == null ? "" : stat!.name),
//           ),
//           Text(
//             stat.toString(),
//           ),
//         ],
//       ),
//     );
//   }
// }
