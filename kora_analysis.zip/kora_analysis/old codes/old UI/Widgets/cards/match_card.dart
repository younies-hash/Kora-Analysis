// import 'package:flutter/material.dart';
// import 'package:kora_analysis/BL/football_match.dart';

// class MatchCard extends StatelessWidget {
//   final FootballMatch match;
//   final Function? action;
//   const MatchCard(
//     this.match, {
//     super.key,
//     this.action,
//   });
//   @override
//   Widget build(BuildContext context) {
//     return InkWell(
//       onTap: action != null ? action!() : () {},
//       child: ListTile(
//         leading: Image.asset(
//           "assets/tournaments/${match.tour.logo}",
//         ),
//         title: Text("${match.team1} / ${match.team2}"),
//         trailing: const Icon(Icons.play_arrow),
//       ),
//     );
//   }
// }
