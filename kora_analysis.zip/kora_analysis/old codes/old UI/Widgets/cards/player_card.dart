// import 'package:flutter/material.dart';
// import 'package:kora_analysis/BL/Players/player.dart';

// class PlayerCard extends StatelessWidget {
//   final Player player;
//   final Function? action;
//   const PlayerCard(
//     this.player, {
//     super.key,
//     this.action,
//   });
//   @override
//   Widget build(BuildContext context) {
//     return InkWell(
//         onTap: action != null ? action!() : () {},
//         child: ListTile(
//           leading: Image.asset("assets/players/${player.pfp}"),
//           title: Text(player.name),
//           subtitle: Text(player.playerRole),
//           trailing: Center(
//             child: Text("${player.playerNumber}"),
//           ),
//         ));
//   }
// }
