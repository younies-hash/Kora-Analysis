// import 'package:flutter/material.dart';
// import 'package:kora_analysis/BL/country.dart';

// class CountryBox extends StatelessWidget {
//   final Country country;
//   final String? altName;
//   const CountryBox(this.country, {this.altName, super.key});
//   @override
//   Widget build(BuildContext context) {
//     return Center(
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           Text(
//             country.name,
//           ),
//           Image.asset("assets/countries/${country.flag}"),
//         ],
//       ),
//     );
//   }
// }
