//UI/widgets/link.dart
import 'package:flutter/material.dart';
import 'package:kora_analysis/UI/Routing%20Logic/route_generator.dart';

class KoraLink extends StatelessWidget {
  final String text;
  final KoraRoute route;
  final Function func;
  const KoraLink({
    super.key,
    required this.text,
    required this.route,
    required this.func,
  });
  @override
  Widget build(BuildContext context) {
    return Center(
      child: InkWell(
        onTap: () {
          func();
          Navigator.of(context).pushNamed(route.path);
        },
        child: Text(
          text,
          style: const TextStyle(
              color: Colors.blue,
              decoration: TextDecoration.underline,
              decorationColor: Colors.blue),
        ),
      ),
    );
  }
}
