import 'package:flutter/material.dart';
import 'package:kora_analysis/Localization/localizer.dart';
import 'package:provider/provider.dart';

class ErrorDialog{
    final String content;
    final BuildContext context;
    IconData icon = Icons.error;
    ErrorDialog(
        this.context,{
        required this.content,
    });
    void show() {
      final error = Provider.of<Localizer>(context).labels.error;
      final ok = Provider.of<Localizer>(context).labels.ok;
        showDialog<void>(
            context: context,
            builder: (BuildContext context) {
                return AlertDialog(
                    title: Text(error),
                    content: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                            Icon(icon, color: Colors.red,),
                            Text(content),
                        ],
                    ),
                    actions: [
                        TextButton(
                            onPressed: () => Navigator.of(context).pop(),
                            child: Text(ok),
                        ),
                    ],
                );
            },
        );
    }
}
class DialogOption{
    final String name;
    final Function action;
    const DialogOption(this.name,this.action);
}