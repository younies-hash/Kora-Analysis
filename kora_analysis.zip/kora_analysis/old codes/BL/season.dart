// import 'package:kora_analysis/BL/football_match.dart';

// class Season {
//   String id;
//   SeasonDate date;
//   List<FootballMatch> matches;
//   Season({
//     required this.id,
//     required this.date,
//     required this.matches,
//   });
// }

// class SeasonDate {
//   int _year1 = 2000, _year2 = 2000;
//   SeasonDate(int value1, int value2) {
//     _year1 = value1;
//     _year2 = value2;
//   }
//   @override
//   String toString() => "$_year1//$_year2";
// }
