
// import 'package:kora_analysis/BL/Players/stats/advanced_stats.dart';
// import 'package:kora_analysis/BL/Players/stats/basic_stats.dart';

// enum Quarter {
//   firstQuarter,
//   secondQuarter,
//   thirdQuarter,
//   fourthQuarter,
// }

// class QuarterMatch {
//   final Quarter quarter;
//   QuarterMatch({
//     required this.quarter,
//     this.minutesPlayed,
//     this.instructionsFollowed,
//     this.passAccuracy,
//     this.shotAccuracy,
//     this.shortPassAccuracy,
//     this.longPassAccuracy,
//     this.bioReadings,
//   });
//   MinutesPlayed? minutesPlayed;
//   InstructionsFollowed? instructionsFollowed;
//   PassAccuracy? passAccuracy;
//   ShotAccuracy? shotAccuracy;
//   ShortPassAccuracy? shortPassAccuracy;
//   LongPassAccuracy? longPassAccuracy;
//   BioReadings? bioReadings;
  
//   @override
//   String toString() {
//     switch (quarter) {
//       case Quarter.firstQuarter:
//         return "First Quarter";
//       case Quarter.secondQuarter:
//         return "Second Quarter";
//       case Quarter.thirdQuarter:
//         return "Third Quarter";
//       case Quarter.fourthQuarter:
//         return "Fourth Quarter";
//     }
//   }
// }
