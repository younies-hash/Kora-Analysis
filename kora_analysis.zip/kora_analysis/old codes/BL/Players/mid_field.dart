// // ignore_for_file: overridden_fields

// import 'package:kora_analysis/BL/Players/player.dart';
// import 'package:kora_analysis/BL/Players/stats/advanced_stats.dart';

// class Midfield extends Player {
//   Midfield({
//     required super.name,
//     required super.id,
//     required super.playerNumber,
//     required super.team,
//     required super.country,
//   });
//   BallSnatches? ballSnatches;
//   SuccessfulSkirmishes? successfulSkirmishes;
// }

// class MidFieldAttacker extends Midfield implements Role {
//   @override
//   String playerRole = "Mid Field Attacker";

//   MidFieldAttacker({
//     required super.name,
//     required super.id,
//     required super.playerNumber,
//     required super.team,
//     required super.country,
//   });
// }

// class MidFieldDeffender extends Midfield implements Role {
//   @override
//   String playerRole = "Mid Field Deffender";

//   MidFieldDeffender({
//     required super.name,
//     required super.id,
//     required super.playerNumber,
//     required super.team,
//     required super.country,
//   });
// }
