// import 'package:kora_analysis/BL/Players/player.dart';

// class Goal extends Player {
//   @override
//   String playerRole = "Goal";

//   Goal({
//     required super.name,
//     required super.id,
//     required super.playerNumber,
//     required super.team,
//     required super.country,
//   });
// }
