// import 'package:kora_analysis/BL/Players/stats/stat.dart';

// class NumOfMatches implements Stat<int>{
//   @override
//   String name = "Number of past matches";

//   @override
//   int? value;

//   @override
//   int? calc(List args, {int? initVal}) {
//     // TODO: implement calc
//     throw UnimplementedError();
//   }

//   @override
//   void randomize() {
//     // TODO: implement randomize
//   }

//   @override
//   Map<String, dynamic> toMap() {
//     // TODO: implement toMap
//     throw UnimplementedError();
//   }
  
//   fromMap(Map<String, dynamic> map) {
//     // TODO: implement fromMap
//     throw UnimplementedError();
//   }
// }
// class MinutesPlayed implements Stat<int>{
//   @override
//   String name = "Minutes played";
  
//   @override
//   int? value;
  
//   @override
//   int? calc(List args, {int? initVal}) {
//     // TODO: implement calc
//     throw UnimplementedError();
//   }
  
//   fromMap(Map<String, dynamic> map) {
//     // TODO: implement fromMap
//     throw UnimplementedError();
//   }
  
//   @override
//   void randomize() {
//     // TODO: implement randomize
//   }
  
//   @override
//   Map<String, dynamic> toMap() {
//     // TODO: implement toMap
//     throw UnimplementedError();
//   }
// }
// class InstructionsFollowed implements Stat<int>{
//   @override
//   String name = "Instructions Followed";
  
//   @override
//   int? value;
  
//   @override
//   int? calc(List args, {int? initVal}) {
//     // TODO: implement calc
//     throw UnimplementedError();
//   }
  
//   fromMap(Map<String, dynamic> map) {
//     // TODO: implement fromMap
//     throw UnimplementedError();
//   }
  
//   @override
//   void randomize() {
//     // TODO: implement randomize
//   }
  
//   @override
//   Map<String, dynamic> toMap() {
//     // TODO: implement toMap
//     throw UnimplementedError();
//   }
// }
// class PassAccuracy implements Stat<int>{
//   @override
//   String name = "Pass Accuracy";
  
//   @override
//   int? value;
  
//   @override
//   int? calc(List args, {int? initVal}) {
//     // TODO: implement calc
//     throw UnimplementedError();
//   }
  
//   fromMap(Map<String, dynamic> map) {
//     // TODO: implement fromMap
//     throw UnimplementedError();
//   }
  
//   @override
//   void randomize() {
//     // TODO: implement randomize
//   }
  
//   @override
//   Map<String, dynamic> toMap() {
//     // TODO: implement toMap
//     throw UnimplementedError();
//   }
// }
// class ShotAccuracy implements Stat<int>{
//   @override
//   String name = "Shot Accuracy";
  
//   @override
//   int? value;
  
//   @override
//   int? calc(List args, {int? initVal}) {
//     // TODO: implement calc
//     throw UnimplementedError();
//   }
  
//   fromMap(Map<String, dynamic> map) {
//     // TODO: implement fromMap
//     throw UnimplementedError();
//   }
  
//   @override
//   void randomize() {
//     // TODO: implement randomize
//   }
  
//   @override
//   Map<String, dynamic> toMap() {
//     // TODO: implement toMap
//     throw UnimplementedError();
//   }
// }
// class ShortPassAccuracy implements Stat<int>{
//   @override
//   String name = "Short Pass Accuracy";
  
//   @override
//   int? value;
  
//   @override
//   int? calc(List args, {int? initVal}) {
//     // TODO: implement calc
//     throw UnimplementedError();
//   }
  
//   fromMap(Map<String, dynamic> map) {
//     // TODO: implement fromMap
//     throw UnimplementedError();
//   }
  
//   @override
//   void randomize() {
//     // TODO: implement randomize
//   }
  
//   @override
//   Map<String, dynamic> toMap() {
//     // TODO: implement toMap
//     throw UnimplementedError();
//   }
// }
// class LongPassAccuracy implements Stat<int>{
//   @override
//   String name = "Long Pass Accuracy";
  
//   @override
//   int? value;
  
//   @override
//   int? calc(List args, {int? initVal}) {
//     // TODO: implement calc
//     throw UnimplementedError();
//   }
  
//   fromMap(Map<String, dynamic> map) {
//     // TODO: implement fromMap
//     throw UnimplementedError();
//   }
  
//   @override
//   void randomize() {
//     // TODO: implement randomize
//   }
  
//   @override
//   Map<String, dynamic> toMap() {
//     // TODO: implement toMap
//     throw UnimplementedError();
//   }
// }