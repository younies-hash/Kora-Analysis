// import 'package:kora_analysis/DB/api.dart';

// abstract class Stat<T> implements Mapper{
//   T? value;
//   String name = "stat";
//   T? calc(List<dynamic> args,{T? initVal});
//   void randomize();
//   @override
//   String toString() {
//     return "$name:\t${value ?? "N/A"}";
//   }
// }
// // TODO: translate stats names