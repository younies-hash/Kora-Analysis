// //
// //for atker
// //
// import 'package:kora_analysis/BL/Players/stats/stat.dart';

// class SuccessfulOneOnOne implements Stat<int>{
//   @override
//   String name = 'succeddful ones on one';
  
//   @override
//   int? value;
  
//   @override
//   int? calc(List args, {int? initVal}) {
//     // TODO: implement calc
//     throw UnimplementedError();
//   }
  
//   fromMap(Map<String, dynamic> map) {
//     // TODO: implement fromMap
//     throw UnimplementedError();
//   }
  
//   @override
//   void randomize() {
//     // TODO: implement randomize
//   }
  
//   @override
//   Map<String, dynamic> toMap() {
//     // TODO: implement toMap
//     throw UnimplementedError();
//   }
// }
// class Assist implements Stat<int>{
//   @override
//   String name = "assists";
  
//   @override
//   int? value;
  
//   @override
//   int? calc(List args, {int? initVal}) {
//     // TODO: implement calc
//     throw UnimplementedError();
//   }
  
//   fromMap(Map<String, dynamic> map) {
//     // TODO: implement fromMap
//     throw UnimplementedError();
//   }
  
//   @override
//   void randomize() {
//     // TODO: implement randomize
//   }
  
//   @override
//   Map<String, dynamic> toMap() {
//     // TODO: implement toMap
//     throw UnimplementedError();
//   }
// }
// class BallLost implements Stat<int>{
//   @override
//   String name = "Ball lost";

//   @override
//   int? value;
  
//   @override
//   int? calc(List args, {int? initVal}) {
//     // TODO: implement calc
//     throw UnimplementedError();
//   }
  
//   fromMap(Map<String, dynamic> map) {
//     // TODO: implement fromMap
//     throw UnimplementedError();
//   }
  
//   @override
//   void randomize() {
//     // TODO: implement randomize
//   }
  
//   @override
//   Map<String, dynamic> toMap() {
//     // TODO: implement toMap
//     throw UnimplementedError();
//   }
// }
// //
// //def
// //
// class TrapsBroken implements Stat<int>{
//   @override
//   String name = "Traps Broken";

//   @override
//   int? value;
  
//   @override
//   int? calc(List args, {int? initVal}) {
//     // TODO: implement calc
//     throw UnimplementedError();
//   }
  
//   fromMap(Map<String, dynamic> map) {
//     // TODO: implement fromMap
//     throw UnimplementedError();
//   }
  
//   @override
//   void randomize() {
//     // TODO: implement randomize
//   }
  
//   @override
//   Map<String, dynamic> toMap() {
//     // TODO: implement toMap
//     throw UnimplementedError();
//   }
// }
// //
// //for def or midfield
// //
// class BallSnatches implements Stat<int>{
//   @override
//   String name = "Ball Snatches";
  
//   @override
//   int? value;
  
//   @override
//   int? calc(List args, {int? initVal}) {
//     // TODO: implement calc
//     throw UnimplementedError();
//   }
  
//   fromMap(Map<String, dynamic> map) {
//     // TODO: implement fromMap
//     throw UnimplementedError();
//   }
  
//   @override
//   void randomize() {
//     // TODO: implement randomize
//   }
  
//   @override
//   Map<String, dynamic> toMap() {
//     // TODO: implement toMap
//     throw UnimplementedError();
//   }
// }
// class SuccessfulSkirmishes implements Stat<int>{
//   @override
//   String name = "Successful Skirmishes";
  
//   @override
//   int? value;
  
//   @override
//   int? calc(List args, {int? initVal}) {
//     // TODO: implement calc
//     throw UnimplementedError();
//   }
  
//   fromMap(Map<String, dynamic> map) {
//     // TODO: implement fromMap
//     throw UnimplementedError();
//   }
  
//   @override
//   void randomize() {
//     // TODO: implement randomize
//   }
  
//   @override
//   Map<String, dynamic> toMap() {
//     // TODO: implement toMap
//     throw UnimplementedError();
//   }
// }
// //
// //back
// //
// class SuccessfulShorPass implements Stat<int>{
//   @override
//   String name = "Successful Short Passes";

//   @override
//   int? value;
  
//   @override
//   int? calc(List args, {int? initVal}) {
//     // TODO: implement calc
//     throw UnimplementedError();
//   }
  
//   fromMap(Map<String, dynamic> map) {
//     // TODO: implement fromMap
//     throw UnimplementedError();
//   }
  
//   @override
//   void randomize() {
//     // TODO: implement randomize
//   }
  
//   @override
//   Map<String, dynamic> toMap() {
//     // TODO: implement toMap
//     throw UnimplementedError();
//   }
// }
// class FailedShortPass implements Stat<int>{
//   @override
//   String name = "Failed Short Passes";

//   @override
//   int? value;
  
//   @override
//   int? calc(List args, {int? initVal}) {
//     // TODO: implement calc
//     throw UnimplementedError();
//   }
  
//   fromMap(Map<String, dynamic> map) {
//     // TODO: implement fromMap
//     throw UnimplementedError();
//   }
  
//   @override
//   void randomize() {
//     // TODO: implement randomize
//   }
  
//   @override
//   Map<String, dynamic> toMap() {
//     // TODO: implement toMap
//     throw UnimplementedError();
//   }
// }
// //
// //bio readings
// //
// class BioReadings implements Stat<List<double>>{
//   @override
//   String name = "Bio Readings";

//   @override
//   List<double>? value;
  
//   @override
//   List<double>? calc(List args, {List<double>? initVal}) {
//     // TODO: implement calc
//     throw UnimplementedError();
//   }
  
//   fromMap(Map<String, dynamic> map) {
//     // TODO: implement fromMap
//     throw UnimplementedError();
//   }
  
//   @override
//   void randomize() {
//     // TODO: implement randomize
//   }
  
//   @override
//   Map<String, dynamic> toMap() {
//     // TODO: implement toMap
//     throw UnimplementedError();
//   }
// }