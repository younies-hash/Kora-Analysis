// import 'package:flutter/material.dart';
// import 'package:kora_analysis/DB/api.dart';
// import 'package:kora_analysis/UI/Widgets/error_dialog.dart';

// class Points {
//   DBCollection collection;
//   String doc;
//   int points = 0;
//   Points(this.collection, this.doc);
//   void addToFavs(BuildContext context) {
//     int newVal = 0;
//     API.db.collection(collection.id).doc(doc).get().then((data) {
//       newVal = data.data()?["points"] + 1;
//     }, onError: (e) {
//       ErrorDialog(
//         context,
//         content: "Error fetching player points.\n ${e.toString()}",
//       ).show();
//     });
//     try {
//       API.db.collection(collection.id).doc(doc).set({"points": newVal});
//     } catch (e) {
//       ErrorDialog(
//         context,
//         content: "Error updating player points.\n ${e.toString()}",
//       ).show();
//     }
//     points = newVal;
//     //TODO: use transactions instead
//   }
// }
