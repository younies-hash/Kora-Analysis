// // ignore_for_file: overridden_fields

// import 'package:kora_analysis/BL/Players/player.dart';
// import 'package:kora_analysis/BL/Players/stats/advanced_stats.dart';

// class Attacker extends Player {
//   @override
//   String playerRole = "Attacker";

//   Attacker({
//     required super.name,
//     required super.id,
//     required super.playerNumber,
//     required super.team,
//     required super.country,
//   });
//   SuccessfulOneOnOne? successfulOneOnOne;
//   Assist? assist;
//   BallLost? ballLost;
// }

// class SpearHead extends Attacker {
//   @override
//   String playerRole = "Spear Head";

//   SpearHead({
//     required super.name,
//     required super.id,
//     required super.playerNumber,
//     required super.team,
//     required super.country,
//   });
// }

// class RightWing extends Attacker implements Role {
//   @override
//   String playerRole = "Right Wing";

//   RightWing({
//     required super.name,
//     required super.id,
//     required super.playerNumber,
//     required super.team,
//     required super.country,
//   });
// }

// class LeftWing extends Attacker implements Role {
//   @override
//   String playerRole = "Left wing";

//   LeftWing({
//     required super.name,
//     required super.id,
//     required super.playerNumber,
//     required super.team,
//     required super.country,
//   });
// }
