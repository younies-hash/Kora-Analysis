// import 'package:flutter/material.dart';
// import 'package:kora_analysis/BL/Players/points.dart';
// import 'package:kora_analysis/BL/Players/stats/basic_stats.dart';
// import 'package:kora_analysis/BL/Players/stats/stat.dart';
// import 'package:kora_analysis/BL/country.dart';
// import 'package:kora_analysis/BL/football_match.dart';
// import 'package:kora_analysis/BL/team.dart';
// import 'package:kora_analysis/DB/api.dart';
// import 'package:kora_analysis/UI/Widgets/error_dialog.dart';
// import 'package:kora_analysis/default_values.dart';

// class Player extends Points implements Role, Mapper, API<Player> {
//   String name, id, pfp;
//   int playerNumber;
//   @override
//   String playerRole = "N/A";
//   Team team;
//   Country country;
//   FootballMatch? firstMatch;
//   Player({
//     required this.name,
//     required this.id,
//     required this.playerNumber,
//     required this.team,
//     required this.country,
//     this.firstMatch,
//     this.pfp = defPfp,
//     this.history = const [],
//   }) : super(DBCollection.players, id) {
//     basicStats.addAll([
//       totalNumOfMatches,
//       totalMinutesPlayed,
//       totlaInstructionsFollowed,
//       overallPassAccuracy,
//       overallShotAccuracy,
//       overallShortPassAccuracy,
//       overallLongPassAccuracy,
//     ]);
//   }
//   static Player fromMap(Map<String, dynamic> map) {
//     Player p = Player(
//       name: map["name"],
//       id: map["id"],
//       playerNumber: map["playerNumber"],
//       country: map["country"],
//       team: map["team"],
//       pfp: map["pfp"],
//       firstMatch: FootballMatch.fromMap(map["firstMatch"]),
//     );
//     // p.basicStats.forEach((s) => s.value = map[s.name]);
//     return p;
//   }

//   List<FootballMatch> history = [];
//   NumOfMatches totalNumOfMatches = NumOfMatches();
//   MinutesPlayed totalMinutesPlayed = MinutesPlayed();
//   InstructionsFollowed totlaInstructionsFollowed = InstructionsFollowed();
//   PassAccuracy overallPassAccuracy = PassAccuracy();
//   ShotAccuracy overallShotAccuracy = ShotAccuracy();
//   ShortPassAccuracy overallShortPassAccuracy = ShortPassAccuracy();
//   LongPassAccuracy overallLongPassAccuracy = LongPassAccuracy();
//   //
//   List<Stat> basicStats = [
//     // numOfMatches,
//     // totalMinutesPlayed,
//     // totalInstructionFollowed,
//     // overallPassAccuercy,
//     // overallShotAccurecy,
//     // overallShortPassAccuercy,
//     // overallLongPassAccurecy,
//   ];
//   //
//   @override
//   Map<String, dynamic> toMap() {
//     Map<String, dynamic> map = {
//       "name": name,
//       "id": id,
//       "playerNumber": playerNumber,
//       "pfp": pfp,
//       "firstMatch": firstMatch,
//     };
//     for (Stat s in basicStats) {
//       map[s.name] = s.value;
//     }
//     return map;
//   }

//   @override
//   Player fetchObj(BuildContext context) {
//     Map<String, dynamic> map = {};
//     API.db
//         .collection(
//           DBCollection.players.id,
//         )
//         .doc(id)
//         .get()
//         .then((event) {
//       map = event.data() as Map<String, dynamic>;
//     }, onError: (e) {
//       ErrorDialog(
//         context,
//         content: "Error fetching player data.\n ${e.toString()}",
//       ).show();
//     });
//     return fromMap(map);
//   }

//   @override
//   void uploadObj(BuildContext context) {
//     try {
//       API.db
//           .collection(
//             DBCollection.players.id,
//           )
//           .doc(id)
//           .set(
//             toMap(),
//           );
//     } catch (e) {
//       ErrorDialog(
//         context,
//         content: "Error uploading player data.\n ${e.toString()}",
//       ).show();
//     }
//   }
// }

// abstract class Role {
//   String playerRole = "";
// }
