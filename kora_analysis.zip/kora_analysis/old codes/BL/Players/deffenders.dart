// import 'package:kora_analysis/BL/Players/player.dart';
// import 'package:kora_analysis/BL/Players/stats/advanced_stats.dart';

// class Deffender extends Player {
//   Deffender({
//     required super.name,
//     required super.id,
//     required super.playerNumber,
//     required super.team,
//     required super.country,
//   });
//   BallSnatches? ballSnatches;
//   SuccessfulSkirmishes? successfulSkermishes;
//   TrapsBroken? trapsBroken;
// }

// class Heart extends Deffender implements Role {
//   @override
//   String playerRole = "Heart";

//   Heart({
//     required super.name,
//     required super.id,
//     required super.playerNumber,
//     required super.team,
//     required super.country,
//   });
// }

// class BackRight extends Deffender implements Role {
//   @override
//   String playerRole = "Back Right";

//   BackRight({
//     required super.name,
//     required super.id,
//     required super.playerNumber,
//     required super.team,
//     required super.country,
//   });
//   SuccessfulShorPass? successfulShorPass;
//   FailedShortPass? failed;
// }

// class BackLeft extends Deffender implements Role {
//   @override
//   String playerRole = "Back Left";

//   BackLeft({
//     required super.name,
//     required super.id,
//     required super.playerNumber,
//     required super.team,
//     required super.country,
//   });
//   SuccessfulShorPass? successfulShorPass;
//   FailedShortPass? failed;
// }
