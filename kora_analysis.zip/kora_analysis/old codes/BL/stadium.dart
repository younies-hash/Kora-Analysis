// import 'package:kora_analysis/BL/country.dart';
// import 'package:kora_analysis/DB/api.dart';

// class Stadium implements Mapper{
//   final String name;
//   final Country country;
//   const Stadium(this.name, this.country);
//   @override
//   Map<String, dynamic> toMap() {
//     return {
//       "name": name,
//       "country": country.toMap(),
//     };
//   }

//   //
//   static Stadium fromMap(Map<String, dynamic> map) => Stadium(
//         map["name"],
//         map["country"],
//       );
// }
