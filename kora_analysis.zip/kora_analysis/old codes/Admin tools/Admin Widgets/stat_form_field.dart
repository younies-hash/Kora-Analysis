// //UI/admin tools/stat_form_field.dart
// class StatFormField extends StatefulWidget{
//     final Player player;
//     final Stat stat;
//     StatBox(this.player,{required this.stat,});

//     _StatFormState createState() => _StatFormState();
// }
// class _StatFormState extends State<StatFormField>{
//     final controller = TextEditingController();
//     final player = widget.player;
//     final stat = widget.stat;
//     @override
//     Widget build(BuildContext context) {
//         return Center(
//             child: ListTile(
//                 title: Text(stat.name),
//                 subTitle: TextFormField(
//                     controller: controller,
//                     decoration: const InputDecoration(
//                         icon: Icon(Icons.vpn_key),
//                         text: stat.toString(),),
//                     onChanged: () {
//                         player.basicStat.where((Stat s) => s.name = stat.name) = stat;
//                     }
//                 ),
//                 // trailing: IconButton(
//                 //     onPressed: () {
//                 //         final type = stat.value.runTimeType();
//                 //         DB.transaction<type>(
//                 //             collection: DBCollections.players,
//                 //             doc: player.name,
//                 //             id: stat.name,
//                 //             updater: (oldValue) => controller.text as type,
//                 //         ),
//                 //     },
//                 //     icon: Icon(Icons.add),
//                 // ),
//             ),
//         );
//     }
// }