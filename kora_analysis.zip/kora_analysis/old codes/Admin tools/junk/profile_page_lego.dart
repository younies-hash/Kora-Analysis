// import 'package:flutter/material.dart';
// import 'package:my_football_career/Performence%20Tracker/football_match.dart';
// import 'package:my_football_career/Player/player.dart';
// import 'package:my_football_career/UI/Providers/player_cache.dart';
// import 'package:provider/provider.dart';

// //
// String defaultImage = "assets/pfp/blank.jpg";

// //
// class BasicInfo extends StatelessWidget {
//   const BasicInfo({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final cache = Provider.of<PlayerCache>(context);
//     Player? player = cache.player;
//     Role? role = cache.role;
//     return Column(
//       children: [
//         Text(
//           "Name: "
//           "${player == null ? "" : player.name}",
//         ),
//         Text(
//           "Player Number: "
//           "${player == null ? "" : player.playerNumber}",
//         ),
//         Text(
//           "Player Role: "
//           "${role == null ? "" : role.playerRole}",
//         ),
//         Text(
//           "Total Number of Matches: "
//           "${player == null ? "" : (player.totalNumOfMatches == null ? "" : player.totalNumOfMatches!.value.toString())}",
//         ),
//       ],
//     );
//   }
// }

// //
// class Pfp extends StatelessWidget {
//   final double width, height;
//   const Pfp({
//     super.key,
//     required this.width,
//     required this.height,
//   });
//   @override
//   Widget build(BuildContext context) {
//     final cache = Provider.of<PlayerCache>(context);
//     Player? player = cache.player;
//     return SizedBox(
//       height: height,
//       width: width,
//       child: Container(
//         child: player == null
//             ? Image.asset(
//                 defaultImage,
//                 height: height,
//                 width: width,
//               )
//             : player.pfp == null
//                 ? Image.asset(
//                     defaultImage,
//                     height: height,
//                     width: width,
//                   )
//                 : Image(
//                     image: player.pfp!.image,
//                     height: height,
//                     width: width,
//                   ),
//       ),
//     );
//   }
// }

// //
// class MatchList extends StatelessWidget {
//   const MatchList({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final player = Provider.of<PlayerCache>(context).player;
//     final matches = player == null ? [] : player.matches;
//     return SizedBox(
//       height: 500,
//       width: 200,
//       child: ListView(
//         children: [
//           for (FootballMatch m in matches)
//             ListTile(
//               title: Column(
//                 children: [
//                   Text(m.getQuarterSeason()),
//                   Text(m.getTeams()),
//                 ],
//               ),
//               subtitle: Text(m.getDate()),
//             ),
//         ],
//       ),
//     );
//   }
// }
