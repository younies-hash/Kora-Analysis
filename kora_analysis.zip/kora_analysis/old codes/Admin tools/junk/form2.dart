// //
// class DataForm2 extends StatelessWidget{
//     String id = "";
//     late void Function<T>(T) saveFunc;
//     late void Function() delFunc;
//     final provider = IdGenerator(Provider.of<CounterProvider>(context));
//     Widget form;
//     DataForm2.players([this.id]){
//         if(id == ""){
//             id = provider.generatePlayerId();
//         }
//         delFunc = 
//             () => FirebaseFirestore
//                 .instence
//                 .collection("players")
//                 .doc(id);
//         saveFunc = 
//             <Player>(Player newData) => FirebaseFirestore
//                 .instence
//                 .collection("players")
//                 .doc(id)
//                 .set(newData.toMap());
//     }
//     DataForm2.teams([this.id]){
//         if(id == ""){
//             id = provider.generateTeamId();
//         }
//         delFunc = 
//             () => FirebaseFirestore
//                 .instence
//                 .collection("teams")
//                 .doc(id);
//         saveFunc = 
//             <Team>(Team newData) => FirebaseFirestore
//                 .instence
//                 .collection("teams")
//                 .doc(id)
//                 .set(newData.toMap());
//     }
//     DataForm2.tournaments([this.id]){
//         if(id == ""){
//             id = provider.generatetournamentId();
//         }
//         delFunc = 
//             () => FirebaseFirestore
//                 .instence
//                 .collection("tournaments")
//                 .doc(id);
//         saveFunc = 
//             <tournament>(tournament newData) => FirebaseFirestore
//                 .instence
//                 .collection("tournaments")
//                 .doc(id)
//                 .set(newData.toMap());
//     }
//     DataForm2.matches([this.id]){
//         if(id == ""){
//             id = provider.generateMatchId();
//         }
//         delFunc = 
//             () => FirebaseFirestore
//                 .instence
//                 .collection("matches")
//                 .doc(id);
//         saveFunc = 
//             <Match>(Match newData) => FirebaseFirestore
//                 .instence
//                 .collection("matches")
//                 .doc(id)
//                 .set(newData.toMap());
//     }
//     @override
//     Widget build(BuildContext context) {
//         return Scaffold(
//             appBar: AppBar(
//                 actions: IconButton(
//                     onPressed: delFunc,
//                     child: const Icon(Icons.trash),
//                 ),
//             ),
//             body: form,
//             floatingActionButton: FloatingActionButton(
//                 onPressed: saveFunc,
//                 child: const Icon(Icons.save),
//             ),
//         );
//     }
// }