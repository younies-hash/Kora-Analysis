// //UI/screens/data_entry_page.dart.dart
// class DataEntryPage extends StatefulWidget{

//     _DataEntryPageState createState() => _DataEntryPageState();
// }
// class _DataEntryPageState extends State<DataEntryPage>{
//     final nameCont = TextEditingController();
//     final roleCont = TextEditingController();
//     final numCont = TextEditingController();
//     @override
//     Widget build(BuildContext context) {
//         final Player? player = Provider.of<PlayerCache>(context).player;
//         return Scaffold(
//             appBar: DefaultAppBar(context),
//             body: player == null,
//             ? EmptyPageNote(),
//             : Center(
//                 child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: <Widget>[
//                     Row(
//                         children: [
//                             Text("${player.id}"),
//                             IconButton(
//                                 onPressed: (){/*add a new player doc in the db with a new id
//                                 and clears all FormFields
//                                 then waits for input*/},
//                                 child: Icon(Icons.add),
//                             ),
//                             IconButton(
//                                 onPressed: (){/*deletes the player doc with the current id
//                                 and waits for new id to be added*/},
//                                 child: Icon(Icons.trash),
//                             ),
//                         ]),
//                     //FormField for editing player name
//                     //FormField for editing player num
//                     //FormField for editing player role
//                     /* StatFormField for editing every stat
//                         >> every form checks input datatype before accepting it */
//                     ],
//                 ),
//             ),
//         );
//     }
// }