// import 'package:flutter/material.dart';
// import 'package:my_football_career/UI/widgets/LOGO/profile_page_logo.dart';
// class ProfilePage extends StatelessWidget {
//   const ProfilePage({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: SingleChildScrollView(
//         child: LayoutBuilder(
//           builder: (BuildContext context, BoxConstraints constraints) {
//             if (constraints.maxWidth <= 100.0) {
//               return const Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Pfp(width: 100, height: 100),
//                   BasicInfo(),
//                   MatchList(),
//                 ],
//               );
//             } else if (constraints.maxWidth <= 500) {
//               const Column(
//                 children: [
//                   Row(
//                     children: [
//                       Pfp(width: 150, height: 150),
//                       BasicInfo(),
//                     ],
//                   ),
//                   MatchList(),
//                 ],
//               );
//             }
//             return const Row(
//               children: [
//                 Pfp(width: 200, height: 200),
//                 BasicInfo(),
//                 MatchList(),
//               ],
//             );
//           },
//         ),
//       ),
//     );
//   }
// }
