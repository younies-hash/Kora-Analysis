
class DB {
  
  //
  // static T getData<T>(
  //     {required DBCollection colection,
  //     required String doc,
  //     required String id,}
  //     ){
  //     // return Firebase
  //     //     .instence
  //     //     .collection(collection.name)
  //     //     .doc(doc)
  //     //     .get(id) as T;
  // }
  // static Map<String, dynamic> getObj(
  //     {required DBCollection colection,
  //     required String doc,}
  //     ){
  //     // return FirebaseFirestore
  //     //     .instence
  //     //     .collection(collection.name)
  //     //     .doc(doc)T;
  // }
  // static void setData({
  //   required DBCollection colection,
  //   required String doc,
  //   required Map<String, dynamic> newData,
  // }) {
  //   if (newData == {}) return;
  //   // FirebaseFirestore.instence
  //   //     .collection(colection.name).doc(doc).set(newData);
  // }
  // static void updateData<T>({
  //     required String id,
  //     required String doc,
  //     required String colection,
  //     required void Function(Map<String, T> data) func,
  //     }){
  //     T oldData =
  //         FirebaseFirestore
  //             .instence
  //             .collection(collection)
  //             .doc(doc)
  //             .get(id);
  //     FirebaseFirestore
  //         .instence
  //         .collection(collection)
  //         .doc(doc)
  //         .set(func(oldData));
  // }
  // static void delData<T>(
  //     required DBCollection colection,
  //     required String doc,
  //     required String id,
  //     ){
  //     FirebaseFirestore
  //         .instence
  //         .collection(collection)
  //         .doc(doc)
  //         .update({id: FieldValue.delete(),});
  // }
  // static void delDoc<T>(
  //     required DBCollection colection,
  //     required String doc,
  //     ){
  //     FirebaseFirestore
  //         .instence
  //         .collection(collection)
  //         .doc(doc)
  //         .delete();
  // }
  //create a transaction for adding new values,
  // another one for updating old ones,
  // and another one for deleting them
  // static T transaction<T>(
  //     required String id,
  //     required String doc,
  //     required DBCollection colection,
  //     T Function(T data)? updater = null,
  //     ){
  //     FirebaseFirestore.instance
  //         .runTransaction((transaction) async{
  //             final snapShot =
  //             await transaction.get(
  //                 FirebaseFirestore
  //                     .instence
  //                     .collection(collection.name)
  //                     .doc(doc)
  //                     .reference,
  //                 );
  //             final oldValue = snapShot.get(id) as T;
  //             if(updater != null)
  //                 transaction.update(snapShot.reference,{id: func!(oldValue)});
  //             return oldValue;
  //     });
  // }
}
