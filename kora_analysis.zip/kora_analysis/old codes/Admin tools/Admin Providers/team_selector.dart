// import 'package:flutter/material.dart';
// import 'package:kora_analysis/BL/team.dart';
// import 'package:kora_analysis/Providers/team_cache.dart';
// import 'package:provider/provider.dart';

// class SelectedTeamsProvider with ChangeNotifier {
//   List<DropdownMenuItem<Team>> listOfItems = [];
//   SelectedTeamsProvider(BuildContext context) {
//     listOfItems =
//         Provider.of<TeamsCache>(context).getTeams().map<DropdownMenuItem<Team>>(
//       (team) {
//         return DropdownMenuItem<Team>(
//           value: team,
//           child: Text(team.name),
//         );
//       },
//     ).toList();
//   }
//   //
//   Team? _selectedTeam1;
//   Team? _selectedTeam2;
//   //
//   Team? get selectedTeam1 => _selectedTeam1;
//   Team? get selectedTeam2 => _selectedTeam2;
//   void select1(Team t) {
//     _selectedTeam1 = t;
//     notifyListeners();
//   }

//   void select2(Team t) {
//     _selectedTeam2 = t;
//     notifyListeners();
//   }
// }
