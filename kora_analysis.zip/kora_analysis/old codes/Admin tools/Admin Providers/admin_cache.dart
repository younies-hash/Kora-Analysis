// import 'package:kora_analysis/DB/Users/kora_user.dart';
// import 'package:kora_analysis/DB/api.dart';

// class AdminCache {
//   KoraUser? admins;
//   List<KoraUser> allAdmins = [];
//   List<KoraUser> getAdmins() {
//     API.db.collection(DBCollection.admins.id).get().then((admin) {
//       allAdmins = admin.docs.map((doc) => KoraUser.fromMap(doc.data())).toList();
//     });
//     return allAdmins;
//   }
// }
