// import 'package:flutter/material.dart';
// import 'package:kora_analysis/BL/football_match.dart';
// import 'package:kora_analysis/Providers/match_cache.dart';
// import 'package:provider/provider.dart';

// class SelectedMatchProvider with ChangeNotifier{
//   late final List<DropdownMenuItem<FootballMatch>> listOfItems;
//   SelectedMatchProvider(BuildContext context)
//     {listOfItems = 
//         Provider
//         .of<MatchCache>(context)
//         .getFullList()
//         .map<DropdownMenuItem<FootballMatch>>(
//             (match) {
//                 return DropdownMenuItem<FootballMatch>(
//                     value: match,
//                     child: Text(match.toString()),
//                 );
//             },
//         ).toList();}
//     //
//     FootballMatch? _selectedMatch;
//     //
//     FootballMatch? get selectedMatch => _selectedMatch;
//     void select(FootballMatch m) {
//         _selectedMatch = m;
//         notifyListeners();
//     }
// }