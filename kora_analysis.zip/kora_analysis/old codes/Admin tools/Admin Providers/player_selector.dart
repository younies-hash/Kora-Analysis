// import 'package:flutter/material.dart';
// import 'package:kora_analysis/BL/Players/player.dart';
// import 'package:kora_analysis/Providers/player_cache.dart';
// import 'package:provider/provider.dart';

// class SelectedPlayerProvider with ChangeNotifier {
//   late final List<DropdownMenuItem<Player>> listOfItems;
//   SelectedPlayerProvider(BuildContext context) {
//     listOfItems = Provider.of<PlayerCache>(context)
//         .getPlayers()
//         .map<DropdownMenuItem<Player>>(
//       (player) {
//         return DropdownMenuItem<Player>(
//           value: player,
//           child: Text(player.name),
//         );
//       },
//     ).toList();
//   }
//   //
//   Player? _selectedPlayer;
//   //
//   Player? get selectedPlayer => _selectedPlayer;
//   void select(Player p) {
//     _selectedPlayer = p;
//     notifyListeners();
//   }
// }
