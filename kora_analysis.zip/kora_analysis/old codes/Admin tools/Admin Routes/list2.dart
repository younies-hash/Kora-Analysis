// import 'package:flutter/material.dart';
// import 'package:kora_analysis/BL/Players/player.dart';
// import 'package:kora_analysis/BL/football_match.dart';
// import 'package:kora_analysis/BL/team.dart';
// import 'package:kora_analysis/BL/tourenment.dart';
// import 'package:kora_analysis/Providers/match_cache.dart';
// import 'package:kora_analysis/Providers/player_cache.dart';
// import 'package:kora_analysis/Providers/team_cache.dart';
// import 'package:kora_analysis/UI/Widgets/cards/match_card.dart';
// import 'package:kora_analysis/UI/Widgets/cards/player_card.dart';
// import 'package:kora_analysis/UI/Widgets/cards/team_card.dart';
// import 'package:kora_analysis/UI/Widgets/cards/tour_card.dart';
// import 'package:kora_analysis/UI/Widgets/default_app_bar.dart';
// import 'package:provider/provider.dart';

// class List2 extends StatelessWidget {
//   late final Function route;
//   late final List<Widget> listOfDevCards;
//   List2.players(BuildContext context, {super.key}) {
//     // route = () {
//     //             Provider.of<PlayerCache>(context).player = null;
//     //             // Navigator.of(context).pushNamed(playerForm.path);
//     // };
//     listOfDevCards = [
//       for (Player player in Provider.of<PlayerCache>(context).getPlayers())
//         PlayerCard(
//           player,
//           //actio: route
//         ),
//     ];
//   }
//   List2.teams(BuildContext context, {super.key}) {
//     // route = () {
//     //             Provider.of<PlayerCache>(context).player = null;
//     //             // Navigator.of(context).pushNamed(playerForm.path);
//     // };
//     listOfDevCards = [
//       for (Team team in Provider.of<TeamsCache>(context).getTeams())
//         TeamCard(
//           team,
//           // (){
//           //     Provider.of<TeamCache>(context)?.team = team;
//           //     Navigator.of(contex)?.pushNamed(
//           //         AdminRouteGenerator.teamForm.path,
//           //     );
//           // }
//         )
//     ];
//   }
//   List2.tournaments(BuildContext context, {super.key}) {
//     // route = () {
//     //             Provider.of<PlayerCache>(context).player = null;
//     //             // Navigator.of(context).pushNamed(playerForm.path);
//     // };
//     listOfDevCards = [
//       // for (Tournament tour in Provider.of<MatchCache>(context).getTournaments())
//       //   TourCard(
//       //     tour,
//       //     // (){
//       //     //     Provider.of<MatchCache>(context)?.tour = tour;
//       //     //     Navigator.of(contex)?.pushNamed(
//       //     //         AdminRouteGenerator.tourForm.path,
//       //     //     );
//       //     // }
//       //   ),
//     ];
//   }
//   List2.matches(BuildContext context, {super.key}) {
//     // route = () {
//     //             Provider.of<PlayerCache>(context).player = null;
//     //             // Navigator.of(context).pushNamed(playerForm.path);
//     // };
//     listOfDevCards = [
//       // for (FootballMatch match in Provider.of<MatchCache>(context).getMatches())
//       //   MatchCard(
//       //     match,
//       //   ),
//     ];
//   }
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: DefaultAppBar(context),
//       body: ListView(
//         children: listOfDevCards,
//       ),
//       floatingActionButton: FloatingActionButton(
//         onPressed: () {},
//         child: const Icon(Icons.add),
//       ),
//     );
//   }
// }
