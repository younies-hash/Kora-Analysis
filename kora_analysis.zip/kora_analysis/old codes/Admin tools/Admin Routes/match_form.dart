// class MatchForm extends StatefulWidget{

//     _MatchFormState createState() => _MatchFormState()
// }
// class _MatchFormState extends State<MatchForm>{
//     @override
//     Widget build(BuildContext context){
//         final match = Provider.of<MatchCache>(context)?.match
//         ?? Match(
//             id: IdGenerator(Provider.of<CounterProvider>(context)).generateMatchId(),
//             team1: defTeam1,
//             team2: defTeam2,
//         );
//         return Scaffold(
//             appBar: AppBar(
//                 actions: IconButton(
//                     onPressed: DB.delDoc(
//                         collection: DBCollection.matches,
//                         doc: match.id,
//                     ),
//                     child: const Icon(Icons.trash),
//                 ),
//             ),
//             body: ChangeNotifierProvider<SelectedTeamsProvider>(
//                 create: (_) => SelectedTeamsProvider(),
//                 child: SingleChildScrollView(
//                         child: Column(
//                         children: [
//                             Text("ID: ${match.id}"),
//                             Row(
//                                 children: [
//                                     Text("Team1: "),
//                                     Consumer<SelectedTeamsProvider>(
//                                         builder: (context, selected, _){
//                                             return DropdownButtonFormField<Team>(
//                                                 items: selected.listOfItems,
//                                                 value: selected.selectedTeam1,
//                                                 onChanged: (value) =>
//                                                     dropdown.select1(value),
//                                             );
//                                         },
//                                     ),
//                                 ],
//                             ),
//                             Row(
//                                 children: [
//                                     Text("Team2: "),
//                                     Consumer<SelectedTeamsProvider>(
//                                         builder: (context, selected, _){
//                                             return DropdownButtonFormField<Team>(
//                                                 items: selected.listOfItems,
//                                                 value: selected.selectedTeam2,
//                                                 onChanged: (value) =>
//                                                     dropdown.select2(value),
//                                             );
//                                         },
//                                     ),
//                                 ],
//                             ),
//                         ],
//                     ),
//                 ),
//             ),
//             floatingActionButton: FloatingActionButton(
//                 onPressed: (){
//                     DB.setData(
//                         collection: DBCollection.mathes,
//                         doc: match.id,
//                         newData: match.toMap(),
//                     );
//                     final playerList = Provider.of<PlayerCache>(context)?.allPlayers;
//                     for(Player p in playerList){
//                         if(match.team1.contains(p) || match.team2.contains(p)){
//                             p.history.add(match);
//                             DB.setData(
//                                 collection: DBCollection.players,
//                                 doc: p.id,
//                                 newData: {"history": p.history},
//                             );
//                         }
//                     }
//                 },
//                 child: const Icon(Icons.save),
//             ),
//         );
//     }
// }