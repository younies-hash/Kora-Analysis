// class TourForm extends StatefulWidget{

//     _TourFormState createState() => _TourFormState()
// }
// class _TourFormState extends State<TourForm>{
//     @override
//     Widget build(BuildContext context){
//         final nameControl = TextEditingController();
//         final tour = Provider.of<MatchCache>(context)?.tour
//         ?? deftournament;
//         return Scaffold(
//             appBar: AppBar(
//                 actions: IconButton(
//                     onPressed: DB.delDoc(
//                         collection: DBCollection.tour,
//                         doc: tour.id,
//                     ),
//                     child: const Icon(Icons.trash),
//                 ),
//             ),
//             body: ChangeNotifierProvider<SelectedMatchProvider>(
//                 create: (_) => SelectedMatchProvider(),
//                 child: SingleChildScrollView(
//                         child: Column(
//                         children: [
//                             //logo
//                             InkWell(
//                                 onPressed: (){
//                                     //browse files and select an image
//                                 },
//                                 child: tour.logo,
//                             ),
//                             Text("ID: ${tour.id}"),
//                             Row(
//                                 children: [
//                                     Text("tournament Name: "),
//                                     TextFormField(controller: nameControl),
//                                 ],
//                             ),
//                             Consumer<SelectedPlayerProvider>(
//                                 builder: (context, selected, _){
//                                     return Column(
//                                         children:[
//                                             Text("Matches:"),
//                                             for(Player p in team.listOfPlayers) 
//                                                 Row(
//                                                     children: [
//                                                         PlayerCard(p, (){}),
//                                                         IconButton(
//                                                             icon: Icon(
//                                                                 Icons.trash,
//                                                                 () {
//                                                                     team.listOfPlayers.remove(p);
//                                                                 },
//                                                             ),
//                                                         ),
//                                                     ],
//                                                 ),
//                                             Row(
//                                                 children: [
//                                                     Text("Add Players: "),
//                                                     DropdownButtonFormField<Player>(
//                                                         items: selected.listOfItems,
//                                                         value: selected.selectedPlayer,
//                                                         onChanged: (value) {
//                                                             selected.select(value);
//                                                             player.listOfPlayers.add(value);
//                                                         },
//                                                     );
//                                                 ],
//                                             ),
//                                         ],
//                                     );
//                                 },
//                             ),
//                         ],
//                     ),
//                 ),
//             ),
//             floatingActionButton: FloatingActionButton(
//                 onPressed: (){
//                     team.name = nameControl.text;
//                     team.country = countryControl.text;
//                     DB.setData(
//                         collection: DBCollection.teams,
//                         doc: team.id,
//                         newData: team.toMap(),
//                     );
//                 },
//                 child: const Icon(Icons.save),
//             ),
//         );
//     }
// }