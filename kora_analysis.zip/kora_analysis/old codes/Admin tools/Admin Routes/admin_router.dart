// //UI/screens/routeing_logic.dart
// import 'package:flutter/material.dart';
// import 'package:kora_analysis/Admin%20tools/Admin%20Routes/list1.dart';
// import 'package:kora_analysis/UI/Routing%20Logic/route_generator.dart';

// class AdminRouteGenerator{
//     static KoraRoute list1 = KoraRoute(
//         "/list 1",
//         MaterialPageRoute(
//             builder: (_) => const List1(),
//         ),
//     );
//     // static  KoraRoute list2 = KoraRoute(
//     //     "/list 2",
//     //     MaterialPageRoute(
//     //         builder: (_) => List2(),
//     //     ),
//     // );
//     // static  KoraRoute playerForm = KoraRoute(
//     //     "/player form",
//     //     MaterialPageRoute(
//     //         builder: (_) => PlayerForm(),
//     //     ),
//     // );
//     //
//     static  List<KoraRoute> allRoutes = [
//         list1,
//         // list2,
//         // playerForm,
//     ];
//     static Route<dynamic> generateRoute(RouteSettings settings){
//         for(KoraRoute yr in allRoutes){
//             if(settings.name == yr.path) return yr.pageRoute;
//         }
//         return RouteGenerator.home.pageRoute;
//     }
// }