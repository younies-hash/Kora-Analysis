// class TeamForm extends StatefulWidget{

//     _TeamFormState createState() => _TeamFormState()
// }
// class _TeamFormState extends State<TeamForm>{
//     @override
//     Widget build(BuildContext context){
//         final nameControl = TextEditingController(),
//         countryControl = TextEditingController();
//         final team = Provider.of<TeamCache>(context)?.team
//         ?? defTeam1;
//         return Scaffold(
//             appBar: AppBar(
//                 actions: IconButton(
//                     onPressed: DB.delDoc(
//                         collection: DBCollection.team,
//                         doc: team.id,
//                     ),
//                     child: const Icon(Icons.trash),
//                 ),
//             ),
//             body: ChangeNotifierProvider<SelectedPlayerProvider>(
//                 create: (_) => SelectedPlayerProvider(),
//                 child: SingleChildScrollView(
//                         child: Column(
//                         children: [
//                             //logo
//                             InkWell(
//                                 onPressed: (){
//                                     //browse files and select an image
//                                 },
//                                 child: team.logo,
//                             ),
//                             Text("ID: ${team.id}"),
//                             Row(
//                                 children: [
//                                     Text("Team Name: "),
//                                     TextFormField(controller: nameControl),
//                                 ],
//                             ),
//                             Row(
//                                 children: [
//                                     Text("Country: "),
//                                     TextFormField(controller: countryControl),
//                                 ],
//                             ),
//                             Consumer<SelectedPlayerProvider>(
//                                 builder: (context, selected, _){
//                                     return Column(
//                                         children:[
//                                             Text("Players:"),
//                                             for(Player p in team.listOfPlayers) 
//                                                 Row(
//                                                     children: [
//                                                         PlayerCard(p, (){}),
//                                                         IconButton(
//                                                             icon: Icon(
//                                                                 Icons.trash,
//                                                                 () {
//                                                                     team.listOfPlayers.remove(p);
//                                                                 },
//                                                             ),
//                                                         ),
//                                                     ],
//                                                 ),
//                                             Row(
//                                                 children: [
//                                                     Text("Add Players: "),
//                                                     DropdownButtonFormField<Player>(
//                                                         items: selected.listOfItems,
//                                                         value: selected.selectedPlayer,
//                                                         onChanged: (value) {
//                                                             selected.select(value);
//                                                             player.listOfPlayers.add(value);
//                                                         },
//                                                     );
//                                                 ],
//                                             ),
//                                         ],
//                                     );
//                                 },
//                             ),
//                         ],
//                     ),
//                 ),
//             ),
//             floatingActionButton: FloatingActionButton(
//                 onPressed: (){
//                     team.name = nameControl.text;
//                     team.country = countryControl.text;
//                     DB.setData(
//                         collection: DBCollection.teams,
//                         doc: team.id,
//                         newData: team.toMap(),
//                     );
//                 },
//                 child: const Icon(Icons.save),
//             ),
//         );
//     }
// }