// import 'package:flutter/material.dart';

// class PlayerForm extends StatefulWidget{

//     _PlayerFormState createState() => _PlayerFormState()
// }
// class _PlayerFormState extends State<PlayerForm>{
//     @override
//     Widget build(BuildContext context){
//         final nameControl = TextEditingController(),
//         numControl = TextEditingController(),
//         roleControl = TextEditingController(),
//         countryControl = TextEditingController();
//         final player = Provider.of<PlayerCache>(context)?.player
//         ?? Player(
//             id: IdGenerator(Provider.of<CounterProvider>(context)).generatePlayerId(),
//             name: "",
//             playerNum: 0,
//         );
//         return Scaffold(
//             appBar: AppBar(
//                 actions: IconButton(
//                     onPressed: DB.delDoc(
//                         collection: DBCollection.players,
//                         doc: player.id,
//                     ),
//                     child: const Icon(Icons.trash),
//                 ),
//             ),
//             body: SingleChildScrollView(
//                 child: Column(
//                     children: [
//                         //pfp
//                         InkWell(
//                             onPressed: (){
//                                 //browse files and select an image
//                             },
//                             child: player.pfp,
//                         ),
//                         //Id - name - namber - role - country
//                         Text("ID: ${player.id}"),
//                         Row(
//                             children: [
//                                 Text("Player Name: "),
//                                 TextFormField(controller: nameControl),
//                             ],
//                         ),
//                         Row(
//                             children: [
//                                 Text("Player Number: "),
//                                 TextFormField(controller: numControl),
//                             ],
//                         ),
//                         Row(
//                             children: [
//                                 Text("Player Role: "),
//                                 TextFormField(controller: roleControl),
//                             ],
//                         ),
//                         Row(
//                             children: [
//                                 Text("Country: "),
//                                 TextFormField(controller: countryControl),
//                             ],
//                         ),
//                         //stats
//                         for(Stat s in player.basicStats) StatFormField(player, stat: s),
//                         //TODO: add a method to enter match history
//                     ],
//                 ),
//             ),
//             floatingActionButton: FloatingActionButton(
//                 onPressed: (){
//                     player.name = nameControl.text;
//                     player.playerNum = numControl.text;
//                     player.role = roleControl.text;
//                     player.country = Country(nameControl.text);
//                     DB.setData(
//                         collection: DBCollection.players,
//                         doc: player.id,
//                         newData: player.toMap(),
//                     );
//                 },
//                 child: const Icon(Icons.save),
//             ),
//         );
//     }
// }