package com.example.kora_analysis

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
