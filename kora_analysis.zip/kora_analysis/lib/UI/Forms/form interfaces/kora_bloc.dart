import 'package:bloc/bloc.dart';
import 'package:kora_analysis/Architecture/interfaces/kora_obj.dart';
import 'package:kora_analysis/UI/Forms/form%20interfaces/events.dart';

class KoraBloc<Obj extends KoraObj> extends Bloc<KoraEvent, Obj> {
  KoraBloc(super.initialState) {
    on<KoraEvent>((event, emit) {
      event.apply(state);
      emit(state);
    });
  }
}
