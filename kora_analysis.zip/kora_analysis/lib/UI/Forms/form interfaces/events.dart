import 'package:kora_analysis/Architecture/Kora%20Objects/country.dart';
import 'package:kora_analysis/Architecture/interfaces/kora_obj.dart';

abstract class KoraEvent<T extends KoraObj>{
  void apply(T obj);
}

class RenameObj extends KoraEvent<KoraObj>{
  final String newName;
  RenameObj(this.newName);
  @override
  void apply(KoraObj obj) => obj.name = newName;
}

class SetRigion extends KoraEvent<KoraObj>{
  final Country newRigion;
  SetRigion(this.newRigion);
  
  @override
  void apply(KoraObj obj) => obj.country = newRigion;
}