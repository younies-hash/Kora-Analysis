import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:kora_analysis/Architecture/Kora%20Objects/team.dart';
import 'package:kora_analysis/UI/Forms/Team%20Form/team_form_bloc.dart';
import 'package:kora_analysis/UI/Forms/form%20interfaces/events.dart';
import 'package:kora_analysis/UI/Widgets/data_box.dart';
import 'package:kora_analysis/UI/Widgets/default_app_bar.dart';
import 'package:kora_analysis/UI/Widgets/input_box.dart';
import 'package:provider/provider.dart';

class TeamForm extends StatelessWidget {
  final TextEditingController nameControl = TextEditingController();

  TeamForm({super.key});
  @override
  Widget build(BuildContext context) {
    final bloc = Provider.of<TeamFormBloc>(context, listen: false);
    final team = bloc.state;
    return Scaffold(
      appBar: DefaultAppBar(context, pageTitle: 'Team Form'),
      body: SingleChildScrollView(
        child: BlocBuilder<TeamFormBloc, Team>(
          bloc: bloc,
          builder: (context, state) {
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  DataBox('ID:\t', team.id),
                  const SizedBox(height: 12),
                  InputBox(
                    'Team Name:\t',
                    nameControl,
                    // this code isn't working as it should
                    onChanged: () => bloc.add(RenameObj(nameControl.text)),
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () =>
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: const Text('Attention!'),
              content: Text('${team.id} - ${team.name}'),
            ),
          ),
        child: const Icon(Icons.save),
      ),
    );
  }
}
