import 'package:kora_analysis/Architecture/Kora%20Objects/team.dart';
import 'package:kora_analysis/UI/Forms/form%20interfaces/kora_bloc.dart';

class TeamFormBloc extends KoraBloc<Team>{
  TeamFormBloc(super.initialState);
}