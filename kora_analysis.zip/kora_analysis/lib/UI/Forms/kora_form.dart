import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:kora_analysis/Architecture/Kora%20Objects/team.dart';
import 'package:kora_analysis/Architecture/interfaces/kora_obj.dart';
import 'package:kora_analysis/UI/Forms/Team%20Form/team_form.dart';
import 'package:kora_analysis/UI/Forms/Team%20Form/team_form_bloc.dart';
import 'package:kora_analysis/UI/Widgets/default_app_bar.dart';
import 'package:kora_analysis/UI/Widgets/empty_page_widget.dart';


class KoraForm<obj extends KoraObj> extends StatelessWidget{
  final obj initValue;
  const KoraForm(this.initValue, {super.key});

  @override
  Widget build(BuildContext context) {
    if(initValue is Team){
        return BlocProvider(
          create: (context) => TeamFormBloc(initValue as Team),
          child: TeamForm(),
        );
    } else {
      return Scaffold(
        appBar: DefaultAppBar(context),
        body: const EmptyPageNote(),
      );
    }
  }
}