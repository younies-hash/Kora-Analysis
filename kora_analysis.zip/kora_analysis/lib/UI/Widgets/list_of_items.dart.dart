import 'package:flutter/material.dart';
import 'package:kora_analysis/Architecture/interfaces/kora_cache.dart';
import 'package:kora_analysis/Architecture/interfaces/kora_obj.dart';
import 'package:kora_analysis/UI/Routing%20Logic/route_generator.dart';
import 'package:kora_analysis/UI/Widgets/empty_page_widget.dart';

class ListOfItems<Obj extends KoraObj> extends StatelessWidget {
  final List<Obj> list;
  final Widget Function(Obj item, Function action) builder;
  final KoraCache<Obj>? cache;
  final Function? action;
  final KoraRoute? route;
  const ListOfItems(
    this.list, {
    super.key,
    required this.builder,
    this.action,
    this.cache,
    this.route,
  });
  @override
  Widget build(BuildContext context) {
    return list.isNotEmpty
        ? Column(
            children: [
              for (Obj item in list)
                builder(
                  item,
                  action != null
                      ? action!
                      : (cache != null && route != null)
                          ? () {
                              cache!.itemCache = item;
                              Navigator.of(context).pushNamed(route!.path);
                            }
                          : () {},
                ),
            ],
          )
        : const EmptyPageNote();
  }
}
