import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ItemCard<T> extends StatelessWidget {
  String title, content;
  Widget? pic, icon;
  Function action;
  ItemCard({
    super.key,
    required this.title,
    required this.content,
    this.pic,
    this.icon,
    required this.action,
  });
  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: pic,
      title: Text(title),
      subtitle: Text(content),
      trailing: icon,
      onTap: () => action(),
    );
  }
}
