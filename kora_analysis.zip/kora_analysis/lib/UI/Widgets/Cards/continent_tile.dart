import 'package:flutter/material.dart';
import 'package:kora_analysis/Architecture/Kora%20Objects/continent.dart';
import 'package:kora_analysis/UI/Widgets/cards/Item_card.dart';

// ignore: must_be_immutable
class ContinentTile extends ItemCard {
  final Continent continent;
  ContinentTile(this.continent, Function() router, {super.key})
      : super(
          title: continent.name,
          content: '',
          pic: Image.asset(continent.picPath),
          action: router,
        );
}
