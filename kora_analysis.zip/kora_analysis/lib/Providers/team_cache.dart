import 'package:kora_analysis/Architecture/Kora%20Objects/team.dart';
import 'package:kora_analysis/Architecture/interfaces/kora_cache.dart';

class TeamCache extends KoraCache<Team> {
  @override
  List<Team> getFullList() {
    return listCache;
  }
}
