import 'package:kora_analysis/Architecture/interfaces/kora_obj.dart';

class Country extends BasicKoaObj{
  Country(String name) : super(name,name,"$name-512.png");
  Country.un() : super('un', 'United Nations', 'un.png');
}
