import 'package:kora_analysis/Architecture/Kora%20Objects/country.dart';
import 'package:kora_analysis/Architecture/interfaces/kora_obj.dart';

class Player extends KoraObj {
  Player(
    String id, {
    required String name,
    required Country country,
    String pfp = "assets/images/players/def_pfp.jpg",
  }) : super(id, name, country: country, picPath: pfp);
}
