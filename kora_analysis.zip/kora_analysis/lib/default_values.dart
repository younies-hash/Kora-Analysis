

// class DefaultValues {
//   DefaultValues() {
//     younies.firstMatch = defaultMatch1;
//     younies.history = defaultSeason.matches;
//   }
//   static Player younies = Attacker(
//     name: "Younies",
//     id: "0",
//     playerNumber: 11,
//     team: egyptianNationalTeam,
//     country: egypt,
//   );
//   static Team egyptianNationalTeam = Team(
//     name: "Egyptian National Team",
//     country: egypt,
//     listOfPlayers: [],
//   );

//   static Team zamalek = Team(
//     name: "zamalek",
//     country: egypt,
//     listOfPlayers: [],
//   );
//   static Season defaultSeason = Season(
//       date: SeasonDate(2021, 2022),
//       matches: [
//         defaultMatch1,
//       ],
//       id: 'def_season_id');
//   static FootballMatch defaultMatch1 = FootballMatch(
//     team1: egyptianNationalTeam,
//     team2: zamalek,
//     team1Goals: 0,
//     team2Goals: 2,
//     date: DateTime(2022, 12, 15),
//     tour: deftournament,
//   );
//   static FootballMatch defaultMatch2 = FootballMatch(
//     team1: egyptianNationalTeam,
//     team2: zamalek,
//     team1Goals: 0,
//     team2Goals: 2,
//     date: DateTime(2022, 12, 15),
//     tour: deftournament,
//   );
//   static FootballMatch defaultMatch3 = FootballMatch(
//     team1: egyptianNationalTeam,
//     team2: zamalek,
//     team1Goals: 0,
//     team2Goals: 2,
//     date: DateTime(2022, 12, 15),
//     tour: deftournament,
//   );
//   static FootballMatch defaultMatch4 = FootballMatch(

//     team1: egyptianNationalTeam,
//     team2: zamalek,
//     team1Goals: 0,
//     team2Goals: 2,
//     date: DateTime(2022, 12, 15),
//     tour: deftournament,
//   );
// }
const String defTeamLogo = "def_team_logo.jpg",
defPfp = "def_pfp.jpg",
defFlag = "def_flag.png",
defTourLogo = "def_tour_logo.png";